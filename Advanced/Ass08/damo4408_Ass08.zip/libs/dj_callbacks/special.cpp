/*
 * 
 */
#include "../../dj.h"
void special(int key, int x, int y)
{

}
