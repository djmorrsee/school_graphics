/*
 * textures.h
 *
 *  Created on: Dec 7, 2014
 *      Author: djmorrsee
 */

#ifndef TEXTURES_H_
#define TEXTURES_H_

unsigned int load_texture(std::string filename);

#endif /* TEXTURES_H_ */
