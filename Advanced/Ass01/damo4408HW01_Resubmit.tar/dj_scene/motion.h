
#ifndef __dj_motion
#define __dj_motion

void Rotate(float x, float y);
void Move(facing_t dir);



#endif
