/*
 * glob_const.c
 *
 *  Created on: Dec 1, 2014
 *      Author: djmorrsee
 */

const int c_window_size = 800;

const double c_rot_x_speed = 0.5;
const double c_rot_y_speed = 0.1;

const double c_move_speed = 0.5;


const int c_num_shaders = 2; // None counts as a shader
