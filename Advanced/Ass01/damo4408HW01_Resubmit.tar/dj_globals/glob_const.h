/* 
 * Global Constants for the Project
 */
#ifndef __dj_const
#define __dj_const

extern const int c_window_size;

extern const double c_rot_x_speed;
extern const double c_rot_y_speed;

extern const double c_move_speed;

extern const int c_num_shaders;

#endif
