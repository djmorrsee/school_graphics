/*
 * textures.h
 *
 *  Created on: Dec 7, 2014
 *      Author: djmorrsee
 */

#ifndef TEXTURES_H_
#define TEXTURES_H_

void setup_textures ();

unsigned int LoadBMPTexture(const char* filepath);

#endif /* TEXTURES_H_ */
