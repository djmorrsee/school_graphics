make clean all 2>&1 | grep 'warning\|error'
