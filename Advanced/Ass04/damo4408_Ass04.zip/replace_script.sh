find . -iregex '.*\.c'
