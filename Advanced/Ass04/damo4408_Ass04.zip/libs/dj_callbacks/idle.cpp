/*
 * 
 */
#include "../../dj.h"
void idle() 
{

}
