/*
 * lighting.c
 *
 *  Created on: Dec 4, 2014
 *      Author: djmorrsee
 */

#include "../../dj.h"

LightProperties GetLight(float r, float g, float b, float i) {
	LightProperties l = LightProperties();
}
