/*
 * 
 */
#include "dj.h"
void idle() 
{

	glutPostRedisplay();
}
